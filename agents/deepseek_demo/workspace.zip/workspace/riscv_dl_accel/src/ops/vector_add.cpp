#include "ops/ops.h"
#include "runtime/tensor.h"
#include <cstring>
#include <algorithm>

namespace riscv_dl {

namespace portable {

void vector_add(const Tensor& a, const Tensor& b, Tensor& out) {
    const float* pa = a.data<float>();
    const float* pb = b.data<float>();
    float* pout = out.data<float>();
    size_t n = a.num_elements();

    for (size_t i = 0; i < n; ++i) {
        pout[i] = pa[i] + pb[i];
    }
}

void matrix_mul(const Tensor& A, const Tensor& B, Tensor& C) {
    // A: [M, K], B: [K, N], C: [M, N]
    int M = A.shape()[0];
    int K = A.shape()[1];
    int N = B.shape()[1];

    const float* pA = A.data<float>();
    const float* pB = B.data<float>();
    float* pC = C.data<float>();

    for (int m = 0; m < M; ++m) {
        for (int n = 0; n < N; ++n) {
            float sum = 0.0f;
            for (int k = 0; k < K; ++k) {
                sum += pA[m * K + k] * pB[k * N + n];
            }
            pC[m * N + n] = sum;
        }
    }
}

void relu(const Tensor& input, Tensor& output) {
    const float* pin = input.data<float>();
    float* pout = output.data<float>();
    size_t n = input.num_elements();

    for (size_t i = 0; i < n; ++i) {
        pout[i] = (pin[i] > 0.0f) ? pin[i] : 0.0f;
    }
}

void conv2d_naive(const Tensor& input, const Tensor& kernel, Tensor& output,
                  int stride_h, int stride_w, int pad_h, int pad_w) {
    // input:  [N, IC, IH, IW]
    // kernel: [OC, IC, KH, KW]
    // output: [N, OC, OH, OW]
    int N = input.shape()[0];
    int IC = input.shape()[1];
    int IH = input.shape()[2];
    int IW = input.shape()[3];
    int OC = kernel.shape()[0];
    int KH = kernel.shape()[2];
    int KW = kernel.shape()[3];
    int OH = (IH + 2 * pad_h - KH) / stride_h + 1;
    int OW = (IW + 2 * pad_w - KW) / stride_w + 1;

    const float* pIn = input.data<float>();
    const float* pK = kernel.data<float>();
    float* pOut = output.data<float>();

    for (int n = 0; n < N; ++n) {
        for (int oc = 0; oc < OC; ++oc) {
            for (int oh = 0; oh < OH; ++oh) {
                for (int ow = 0; ow < OW; ++ow) {
                    float sum = 0.0f;
                    for (int ic = 0; ic < IC; ++ic) {
                        for (int kh = 0; kh < KH; ++kh) {
                            int ih = oh * stride_h + kh - pad_h;
                            if (ih < 0 || ih >= IH) continue;
                            for (int kw = 0; kw < KW; ++kw) {
                                int iw = ow * stride_w + kw - pad_w;
                                if (iw < 0 || iw >= IW) continue;
                                sum += pIn[n * IC * IH * IW +
                                          ic * IH * IW +
                                          ih * IW + iw] *
                                       pK[oc * IC * KH * KW +
                                          ic * KH * KW +
                                          kh * KW + kw];
                            }
                        }
                    }
                    pOut[n * OC * OH * OW +
                         oc * OH * OW +
                         oh * OW + ow] = sum;
                }
            }
        }
    }
}

} // namespace portable

} // namespace riscv_dl
