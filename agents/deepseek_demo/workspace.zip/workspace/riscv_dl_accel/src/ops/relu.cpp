// ============================================================================
// ReLU Operator — riscv-dl-accel
// ============================================================================
//
// Implements the Rectified Linear Unit activation function:
//   y[i] = max(0, x[i])
//
// Provides both a portable C++ fallback and a RISC-V-vector-optimized path
// (via in-line assembly or GCC vector builtins) when __riscv_v is defined.
// ============================================================================

#include "ops/dispatch.h"
#include "runtime/api.h"
#include <algorithm>
#include <cstddef>
#include <cstdint>

#ifdef __riscv_v
#include <riscv_vector.h>
#endif

namespace riscv_dl_accel {
namespace ops {

// ---------------------------------------------------------------------------
// Portable fallback
// ---------------------------------------------------------------------------
static void relu_portable(const float *input, float *output, size_t n) {
    for (size_t i = 0; i < n; ++i) {
        output[i] = input[i] > 0.0f ? input[i] : 0.0f;
    }
}

// ---------------------------------------------------------------------------
// RISC-V Vector (V) optimized path using RVV intrinsic macros
// ---------------------------------------------------------------------------
#ifdef __riscv_v
static void relu_rvv(const float *input, float *output, size_t n) {
    size_t i = 0;
    // Process VLEN-sized batches
    while (i < n) {
        size_t vl = __riscv_vsetvl_e32m8(n - i);
        vfloat32m8_t vec = __riscv_vle32_v_f32m8(input + i, vl);
        // Create a zero vector and take element-wise maximum
        vfloat32m8_t zero = __riscv_vfmv_v_f_f32m8(0.0f, vl);
        vfloat32m8_t result = __riscv_vfmax_vv_f32m8(vec, zero, vl);
        __riscv_vse32_v_f32m8(output + i, result, vl);
        i += vl;
    }
}
#endif

// ---------------------------------------------------------------------------
// Dispatched entry point (called from the runtime API)
// ---------------------------------------------------------------------------
dl_error_t dispatch_relu(const Tensor *input, Tensor *output) {
    // Validate inputs
    if (!input || !output) return DL_ERR_NULL_PTR;
    if (input->dtype != DT_FLOAT32) return DL_ERR_UNSUPPORTED_DTYPE;
    if (output->dtype != DT_FLOAT32) return DL_ERR_UNSUPPORTED_DTYPE;

    // Total number of elements
    size_t numel = 1;
    for (int32_t i = 0; i < input->ndim; ++i) {
        numel *= input->dims[i];
    }

    // Check output capacity (flat size must match)
    size_t out_numel = 1;
    for (int32_t i = 0; i < output->ndim; ++i) {
        out_numel *= output->dims[i];
    }
    if (out_numel != numel) return DL_ERR_SHAPE_MISMATCH;

    const float *in_data = reinterpret_cast<const float *>(input->data);
    float *out_data = reinterpret_cast<float *>(output->data);

#ifdef __riscv_v
    relu_rvv(in_data, out_data, numel);
#else
    relu_portable(in_data, out_data, numel);
#endif

    return DL_SUCCESS;
}

} // namespace ops
} // namespace riscv_dl_accel
