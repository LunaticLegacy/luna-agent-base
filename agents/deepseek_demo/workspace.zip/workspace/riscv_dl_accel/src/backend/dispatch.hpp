#ifndef RISCV_DL_ACCEL_BACKEND_DISPATCH_HPP
#define RISCV_DL_ACCEL_BACKEND_DISPATCH_HPP

#include "riscv_dl_accel/core/backend.hpp"

namespace riscv_dl_accel {
namespace backend {

/// @brief Initialize the dispatch layer.
/// Detects CPU features (RISC-V extensions, SIMD) and selects the best backend.
void initialize_dispatch();

/// @brief Get the current active backend.
/// @return Reference to the active Backend instance.
const Backend& active_backend();

/// @brief Check if RISC-V vector (RVV) extension is available.
bool has_rvv();

/// @brief Check if the platform is RISC-V at all.
bool is_riscv();

} // namespace backend
} // namespace riscv_dl_accel

#endif // RISCV_DL_ACCEL_BACKEND_DISPATCH_HPP
