// ============================================================
// riscv_dl_accel — RISC-V Backend Kernel Implementations
// ============================================================
// This file provides RISC-V (RV64) optimised kernel
// implementations for the framework operators.
//
// Each function is guarded by __riscv so compilation on
// non-RISC-V hosts degrades gracefully to the portable path.
// ============================================================

#include "riscv_dl_accel/backend/riscv_kernels.h"
#include <cstring>

namespace riscv_dl_accel {
namespace backend {

// ----------------------------------------------------------
// Vector Add (RVV via intrinsics / inline asm)
// ----------------------------------------------------------
#if defined(__riscv_vector)
#include <riscv_vector.h>
#endif

void rvv_vector_add(const float* a, const float* b,
                    float* dst, std::size_t n) {
#if defined(__riscv_vector)
    std::size_t vl;
    for (std::size_t i = 0; i < n; i += vl) {
        vl = __riscv_vsetvl_e32m8(n - i);
        vfloat32m8_t va = __riscv_vle32_v_f32m8(a + i, vl);
        vfloat32m8_t vb = __riscv_vle32_v_f32m8(b + i, vl);
        vfloat32m8_t vd = __riscv_vfadd_vv_f32m8(va, vb, vl);
        __riscv_vse32_v_f32m8(dst + i, vd, vl);
    }
#else
    // Portable fallback
    for (std::size_t i = 0; i < n; ++i) {
        dst[i] = a[i] + b[i];
    }
#endif
}

// ----------------------------------------------------------
// ReLU (RVV)
// ----------------------------------------------------------
void rvv_relu(const float* src, float* dst, std::size_t n) {
#if defined(__riscv_vector)
    std::size_t vl;
    vfloat32m8_t vzero = __riscv_vfmv_v_f_f32m8(0.0f, __riscv_vsetvlmax_e32m8());
    for (std::size_t i = 0; i < n; i += vl) {
        vl = __riscv_vsetvl_e32m8(n - i);
        vfloat32m8_t vs = __riscv_vle32_v_f32m8(src + i, vl);
        vfloat32m8_t vd = __riscv_vfmax_vv_f32m8(vs, vzero, vl);
        __riscv_vse32_v_f32m8(dst + i, vd, vl);
    }
#else
    for (std::size_t i = 0; i < n; ++i) {
        dst[i] = (src[i] > 0.0f) ? src[i] : 0.0f;
    }
#endif
}

// ----------------------------------------------------------
// Matrix Multiply (RVV — outer-product style)
// ----------------------------------------------------------
void rvv_sgemm(const float* A, const float* B, float* C,
               int M, int N, int K,
               float alpha, float beta) {
#if defined(__riscv_vector)
    // Zero C if beta == 0
    if (beta == 0.0f) {
        std::memset(C, 0, M * N * sizeof(float));
    } else if (beta != 1.0f) {
        for (int i = 0; i < M * N; ++i) C[i] *= beta;
    }

    const int vlmax = __riscv_vsetvlmax_e32m1();

    for (int i = 0; i < M; ++i) {
        for (int k = 0; k < K; ++k) {
            float aik = alpha * A[i * K + k];
            vfloat32m1_t vaik = __riscv_vfmv_v_f_f32m1(aik, vlmax);

            int j = 0;
            for (; j + vlmax <= N; j += vlmax) {
                vfloat32m1_t vb = __riscv_vle32_v_f32m1(B + k * N + j, vlmax);
                vfloat32m1_t vc = __riscv_vle32_v_f32m1(C + i * N + j, vlmax);
                vc = __riscv_vfmacc_vv_f32m1(vc, vaik, vb, vlmax);
                __riscv_vse32_v_f32m1(C + i * N + j, vc, vlmax);
            }

            // Tail
            int vl = __riscv_vsetvl_e32m1(N - j);
            if (vl > 0) {
                vfloat32m1_t vb = __riscv_vle32_v_f32m1(B + k * N + j, vl);
                vfloat32m1_t vc = __riscv_vle32_v_f32m1(C + i * N + j, vl);
                vc = __riscv_vfmacc_vv_f32m1(vc, vaik, vb, vl);
                __riscv_vse32_v_f32m1(C + i * N + j, vc, vl);
            }
        }
    }
#else
    // Portable fallback
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float acc = 0.0f;
            for (int k = 0; k < K; ++k) {
                acc += A[i * K + k] * B[k * N + j];
            }
            if (beta == 0.0f) {
                C[i * N + j] = alpha * acc;
            } else {
                C[i * N + j] = alpha * acc + beta * C[i * N + j];
            }
        }
    }
#endif
}

// ----------------------------------------------------------
// Convolution 2D — im2col + sgemm (portable, but uses RVV sgemm)
// ----------------------------------------------------------
void rvv_conv2d(const float* input, const float* weights,
                float* output,
                int N, int C, int H, int W,
                int K, int R, int S,
                int pad_h, int pad_w,
                int stride_h, int stride_w) {
    // Output dimensions
    int OH = (H + 2 * pad_h - R) / stride_h + 1;
    int OW = (W + 2 * pad_w - S) / stride_w + 1;

    // im2col dimensions: (K) x (C*R*S)  *  (C*R*S) x (OH*OW)
    int col_h = C * R * S;
    int col_w = OH * OW;

    // --- im2col (portable) ---
    auto* col_buf = new float[col_h * col_w];
    int col_idx = 0;
    for (int ci = 0; ci < C; ++ci) {
        for (int ri = 0; ri < R; ++ri) {
            for (int si = 0; si < S; ++si) {
                int out_y = 0;
                for (int h = -pad_h; h + R - pad_h <= H; h += stride_h) {
                    int out_x = 0;
                    for (int w = -pad_w; w + S - pad_w <= W; w += stride_w) {
                        float val = 0.0f;
                        int in_y = h + ri;
                        int in_x = w + si;
                        if (in_y >= 0 && in_y < H && in_x >= 0 && in_x < W) {
                            val = input[ci * H * W + in_y * W + in_x];
                        }
                        col_buf[col_idx * col_w + out_y * OW + out_x] = val;
                        ++out_x;
                    }
                    ++out_y;
                }
                ++col_idx;
            }
        }
    }

    // --- sgemm (RVV accelerated) ---
    // Reshape weights: (K x C*R*S)
    for (int k = 0; k < K; ++k) {
        // Compute C[batch][k][out_y][out_x] += W[k][col] * col_buf[col][out]
        // We'll do a standard sgemm: C(K x col_w) = W(K x col_h) * col_buf(col_h x col_w)
        // For simplicity, use rvv_sgemm row-major: M=K, N=col_w, K_dim=col_h
        // But we need to handle output layout: output is [K][OH][OW]
        // We'll compute row-by-row using rvv_sgemm on each row of weights
    }

    // Simpler: direct sgemm call for the whole matrix
    // W is K x col_h, col_buf is col_h x col_w
    // output (K x col_w) = W * col_buf
    rvv_sgemm(weights, col_buf, output, K, col_w, col_h, 1.0f, 0.0f);

    delete[] col_buf;
}

} // namespace backend
} // namespace riscv_dl_accel
