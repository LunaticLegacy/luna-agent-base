#include "dispatch.hpp"
#include "riscv_dl_accel/core/backend.hpp"
#include <cstring>
#include <cstdlib>
#include <iostream>

namespace riscv_dl_accel {
namespace backend {

// ---------------------------------------------------------------------------
// Portable fallback backend (always available)
// ---------------------------------------------------------------------------
class PortableBackend : public Backend {
public:
    std::string name() const override { return "portable"; }

    void vector_add(const float* a, const float* b, float* c, size_t n) override {
        for (size_t i = 0; i < n; ++i) {
            c[i] = a[i] + b[i];
        }
    }

    void matmul(const float* A, const float* B, float* C,
                size_t M, size_t N, size_t K) override {
        for (size_t i = 0; i < M; ++i) {
            for (size_t j = 0; j < N; ++j) {
                float sum = 0.0f;
                for (size_t k = 0; k < K; ++k) {
                    sum += A[i * K + k] * B[k * N + j];
                }
                C[i * N + j] = sum;
            }
        }
    }

    void relu(const float* x, float* y, size_t n) override {
        for (size_t i = 0; i < n; ++i) {
            y[i] = (x[i] > 0.0f) ? x[i] : 0.0f;
        }
    }

    void conv2d(const float* input, const float* kernel, float* output,
                int H, int W, int KH, int KW,
                int out_h, int out_w) override {
        for (int oh = 0; oh < out_h; ++oh) {
            for (int ow = 0; ow < out_w; ++ow) {
                float sum = 0.0f;
                for (int kh = 0; kh < KH; ++kh) {
                    for (int kw = 0; kw < KW; ++kw) {
                        int ih = oh + kh;
                        int iw = ow + kw;
                        sum += input[ih * W + iw] * kernel[kh * KW + kw];
                    }
                }
                output[oh * out_w + ow] = sum;
            }
        }
    }
};

// ---------------------------------------------------------------------------
// RISC-V backend (uses inline assembly kernels)
// ---------------------------------------------------------------------------
class RiscvBackend : public Backend {
public:
    std::string name() const override { return "riscv_rvv"; }

    void vector_add(const float* a, const float* b, float* c, size_t n) override;
    void matmul(const float* A, const float* B, float* C,
                size_t M, size_t N, size_t K) override;
    void relu(const float* x, float* y, size_t n) override;
    void conv2d(const float* input, const float* kernel, float* output,
                int H, int W, int KH, int KW,
                int out_h, int out_w) override;
};

// Implementations call the standalone RISC-V kernels
void RiscvBackend::vector_add(const float* a, const float* b, float* c, size_t n) {
    rvv_vector_add(a, b, c, n);
}

void RiscvBackend::matmul(const float* A, const float* B, float* C,
                          size_t M, size_t N, size_t K) {
    rvv_matmul(A, B, C, M, N, K);
}

void RiscvBackend::relu(const float* x, float* y, size_t n) {
    rvv_relu(x, y, n);
}

void RiscvBackend::conv2d(const float* input, const float* kernel, float* output,
                          int H, int W, int KH, int KW,
                          int out_h, int out_w) {
    rvv_conv2d(input, kernel, output, H, W, KH, KW, out_h, out_w);
}

// ---------------------------------------------------------------------------
// Dispatch globals
// ---------------------------------------------------------------------------
static PortableBackend g_portable_backend;
static RiscvBackend    g_riscv_backend;
static const Backend*  g_active = nullptr;
static bool            g_has_rvv = false;
static bool            g_is_riscv_platform = false;

// ---------------------------------------------------------------------------
// Platform detection helpers
// ---------------------------------------------------------------------------
static bool detect_riscv_platform() {
#if defined(__riscv)
    return true;
#else
    return false;
#endif
}

static bool detect_rvv() {
#if defined(__riscv_v) || defined(__riscv_vector)
    return true;
#else
    return false;
#endif
}

void initialize_dispatch() {
    g_is_riscv_platform = detect_riscv_platform();
    g_has_rvv = detect_rvv();

    if (g_is_riscv_platform && g_has_rvv) {
        g_active = &g_riscv_backend;
        std::cout << "[riscv-dl-accel] Using RISC-V Vector (RVV) backend.\n";
    } else {
        g_active = &g_portable_backend;
        if (g_is_riscv_platform && !g_has_rvv) {
            std::cout << "[riscv-dl-accel] RISC-V detected but no RVV. "
                      << "Falling back to portable backend.\n";
        } else {
            std::cout << "[riscv-dl-accel] Using portable (scalar) backend.\n";
        }
    }
}

const Backend& active_backend() {
    if (!g_active) {
        initialize_dispatch();
    }
    return *g_active;
}

bool has_rvv() { return g_has_rvv; }
bool is_riscv() { return g_is_riscv_platform; }

} // namespace backend
} // namespace riscv_dl_accel
