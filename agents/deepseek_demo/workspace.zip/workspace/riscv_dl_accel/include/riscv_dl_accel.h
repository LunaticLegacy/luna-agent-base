#ifndef RISCV_DL_ACCEL_H
#define RISCV_DL_ACCEL_H

// Single include header for the riscv_dl_accel framework.
//
// Usage:
//   #include "riscv_dl_accel.h"
//   riscv_dl::Tensor a = riscv_dl::create_tensor({2, 3}, {1,2,3,4,5,6});
//   riscv_dl::Tensor r = riscv_dl::relu(a);

#include "runtime/tensor.h"
#include "runtime/backend.h"
#include "runtime/api.h"
#include "ops/ops.h"

#endif // RISCV_DL_ACCEL_H
