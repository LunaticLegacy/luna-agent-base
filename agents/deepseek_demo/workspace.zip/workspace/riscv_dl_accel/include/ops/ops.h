#ifndef RISCV_DL_ACCEL_OPS_H
#define RISCV_DL_ACCEL_OPS_H

#include "../runtime/tensor.h"
#include "../runtime/backend.h"

namespace riscv_dl {
namespace ops {

// ============================================================
// Vector Add: out[i] = a[i] + b[i]
// ============================================================
// Shapes: a and b must have the same shape, or be broadcastable.
// Current implementation requires matching shapes.
void vector_add_portable(const Tensor& a, const Tensor& b, Tensor& out);
void vector_add_rv64gc(const Tensor& a, const Tensor& b, Tensor& out);

// ============================================================
// Matrix Multiplication: out = a * b
// ============================================================
// Shapes: a is [M, K], b is [K, N], out is [M, N]
void matmul_portable(const Tensor& a, const Tensor& b, Tensor& out);
void matmul_rv64gc(const Tensor& a, const Tensor& b, Tensor& out);

// ============================================================
// ReLU: out[i] = max(0, in[i])
// ============================================================
void relu_portable(const Tensor& in, Tensor& out);
void relu_rv64gc(const Tensor& in, Tensor& out);

// ============================================================
// 2D Convolution (naive)
// ============================================================
// input:  [N, C, H, W]
// kernel: [OC, C, KH, KW]
// output: [N, OC, H_out, W_out]
void conv2d_portable(const Tensor& input, const Tensor& kernel,
                     Tensor& output, int stride, int pad);
void conv2d_rv64gc(const Tensor& input, const Tensor& kernel,
                   Tensor& output, int stride, int pad);

} // namespace ops

// ============================================================
// High-level C++ API
// ============================================================

// --- Tensor creation ---
inline Tensor zeros(const std::vector<size_t>& shape, DataType dtype = DataType::F32) {
    return Tensor(shape, dtype);
}

inline Tensor ones(const std::vector<size_t>& shape, DataType dtype = DataType::F32) {
    Tensor t(shape, dtype);
    t.fill<float>(1.0f);
    return t;
}

// --- Operator API ---
inline Tensor add(const Tensor& a, const Tensor& b) {
    // Broadcasting check: ensure shapes match for now
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("add: shape mismatch");
    }
    Tensor out(a.shape(), a.dtype());
    dispatch_vector_add(a, b, out);
    return out;
}

inline Tensor matmul(const Tensor& a, const Tensor& b) {
    if (a.ndim() != 2 || b.ndim() != 2) {
        throw std::invalid_argument("matmul: inputs must be 2D");
    }
    size_t M = a.dim(0), K = a.dim(1);
    size_t K2 = b.dim(0), N = b.dim(1);
    if (K != K2) {
        throw std::invalid_argument("matmul: inner dimensions mismatch");
    }
    Tensor out({M, N}, a.dtype());
    dispatch_matmul(a, b, out);
    return out;
}

inline Tensor relu(const Tensor& in) {
    Tensor out(in.shape(), in.dtype());
    dispatch_relu(in, out);
    return out;
}

inline Tensor conv2d(const Tensor& input, const Tensor& kernel,
                     int stride = 1, int pad = 0) {
    if (input.ndim() != 4 || kernel.ndim() != 4) {
        throw std::invalid_argument("conv2d: input and kernel must be 4D");
    }
    size_t N = input.dim(0), C = input.dim(1), H = input.dim(2), W = input.dim(3);
    size_t OC = kernel.dim(0), KC = kernel.dim(1), KH = kernel.dim(2), KW = kernel.dim(3);
    if (C != KC) {
        throw std::invalid_argument("conv2d: channel mismatch");
    }
    size_t H_out = (H + 2 * pad - KH) / stride + 1;
    size_t W_out = (W + 2 * pad - KW) / stride + 1;
    Tensor out({N, OC, H_out, W_out}, input.dtype());
    dispatch_conv2d(input, kernel, out, stride, pad);
    return out;
}

} // namespace riscv_dl

#endif // RISCV_DL_ACCEL_OPS_H
