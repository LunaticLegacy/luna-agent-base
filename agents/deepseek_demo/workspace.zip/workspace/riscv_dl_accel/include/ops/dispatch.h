#ifndef RISCV_DL_ACCEL_DISPATCH_H
#define RISCV_DL_ACCEL_DISPATCH_H

#include "runtime/backend.h"
#include "runtime/tensor.h"

// ============================================================================
// Operator dispatch layer
// ============================================================================
// Each operator is defined as a struct with a static 'eval' method.
// The dispatch mechanism selects the best available backend at runtime.
//
// Backend selection priority:
//   1. User-forced backend (via force_backend)
//   2. RISC-V inline-asm if __riscv__ is defined
//   3. Fallback to portable C++

namespace riscv_dl {
namespace dispatch {

// --- Vector Add -------------------------------------------------------------
struct Add {
    static Tensor eval(const Tensor& a, const Tensor& b);
};

// --- ReLU -------------------------------------------------------------------
struct ReLU {
    static Tensor eval(const Tensor& x);
};

// --- Matrix Multiply --------------------------------------------------------
struct MatMul {
    static Tensor eval(const Tensor& a, const Tensor& b);
};

// --- 2D Convolution (naive) -------------------------------------------------
struct Conv2D {
    static Tensor eval(const Tensor& input, const Tensor& filters,
                       int32_t stride_h, int32_t stride_w,
                       int32_t pad_h,   int32_t pad_w);
};

} // namespace dispatch
} // namespace riscv_dl

#endif // RISCV_DL_ACCEL_DISPATCH_H
