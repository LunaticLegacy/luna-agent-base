#ifndef RISCV_DL_ACCEL_BACKEND_H
#define RISCV_DL_ACCEL_BACKEND_H

#include <cstdint>
#include <memory>
#include <string>
#include "tensor.h"

namespace riscv_dl {

// Backend type enumeration
enum class BackendType : uint8_t {
    PORTABLE = 0,    // Naive C++ reference implementation
    RV64GC  = 1,     // RISC-V 64-bit general-purpose (with inline asm)
    RVV     = 2,     // RISC-V Vector Extension (if available)
    AUTO    = 255    // Auto-detect best available
};

inline const char* backend_name(BackendType bt) {
    switch (bt) {
        case BackendType::PORTABLE: return "Portable C++";
        case BackendType::RV64GC:   return "RV64GC (inline asm)";
        case BackendType::RVV:      return "RVV (vector)";
        default:                    return "Unknown";
    }
}

// Forward declarations
class Tensor;
struct Backend;

// ============================================================
// Operator function pointer signatures
// ============================================================

using add_fn   = void (*)(const Tensor& a, const Tensor& b, Tensor& out);
using mul_fn   = void (*)(const Tensor& a, const Tensor& b, Tensor& out);
using relu_fn  = void (*)(const Tensor& in, Tensor& out);
using conv_fn  = void (*)(const Tensor& input, const Tensor& kernel,
                          Tensor& output, int stride, int pad);

// ============================================================
// Backend structure: holds function pointers for all ops
// ============================================================

struct Backend {
    BackendType type;
    std::string name;

    add_fn  vector_add  = nullptr;
    mul_fn  matmul      = nullptr;
    relu_fn relu        = nullptr;
    conv_fn conv2d      = nullptr;

    Backend(BackendType t) : type(t), name(backend_name(t)) {}
    virtual ~Backend() = default;
};

// ============================================================
// Backend registry / dispatch
// ============================================================

class BackendManager {
public:
    // Get the global singleton
    static BackendManager& instance();

    // Register a backend
    void register_backend(std::unique_ptr<Backend> backend);

    // Set active backend by type
    bool set_active(BackendType type);

    // Set active to AUTO: detect best available at runtime
    void set_auto();

    // Get active backend
    Backend* active();

    // Detect best available backend at compile/runtime
    static BackendType detect_best_backend();

    // Check if running on RISC-V (compile-time macro + runtime fallback)
    static bool is_riscv();

private:
    BackendManager() = default;
    std::unique_ptr<Backend> backends_[256] = {};
    BackendType active_type_ = BackendType::PORTABLE;
};

// ============================================================
// Convenience: dispatch helpers
// ============================================================

inline void dispatch_vector_add(const Tensor& a, const Tensor& b, Tensor& out) {
    auto* be = BackendManager::instance().active();
    if (be && be->vector_add) be->vector_add(a, b, out);
}

inline void dispatch_matmul(const Tensor& a, const Tensor& b, Tensor& out) {
    auto* be = BackendManager::instance().active();
    if (be && be->matmul) be->matmul(a, b, out);
}

inline void dispatch_relu(const Tensor& in, Tensor& out) {
    auto* be = BackendManager::instance().active();
    if (be && be->relu) be->relu(in, out);
}

inline void dispatch_conv2d(const Tensor& input, const Tensor& kernel,
                            Tensor& output, int stride, int pad) {
    auto* be = BackendManager::instance().active();
    if (be && be->conv2d) be->conv2d(input, kernel, output, stride, pad);
}

} // namespace riscv_dl

#endif // RISCV_DL_ACCEL_BACKEND_H
