#ifndef RISCV_DL_ACCEL_TENSOR_H
#define RISCV_DL_ACCEL_TENSOR_H

#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <vector>

namespace riscv_dl {

// Supported data types
enum class DataType : uint8_t {
    F32 = 0,
    F64 = 1,
    I32 = 2,
    I8  = 3,
    U8  = 4
};

inline size_t data_type_size(DataType dt) {
    switch (dt) {
        case DataType::F32: return 4;
        case DataType::F64: return 8;
        case DataType::I32: return 4;
        case DataType::I8:  return 1;
        case DataType::U8:  return 1;
        default: return 4;
    }
}

// Tensor class: multi-dimensional array with contiguous memory (row-major)
class Tensor {
public:
    // Default constructor: empty tensor
    Tensor() : data_(nullptr), size_(0), capacity_(0), owned_(false) {}

    // Construct with shape; memory allocated internally
    Tensor(const std::vector<size_t>& shape, DataType dtype = DataType::F32)
        : shape_(shape), dtype_(dtype), owned_(true) {
        size_ = compute_size(shape);
        capacity_ = size_ * data_type_size(dtype);
        if (capacity_ > 0) {
            data_ = std::aligned_alloc(64, capacity_);
            if (!data_) {
                throw std::bad_alloc();
            }
            std::memset(data_, 0, capacity_);
        } else {
            data_ = nullptr;
        }
    }

    // Construct from existing buffer (does NOT take ownership)
    Tensor(void* buffer, const std::vector<size_t>& shape, DataType dtype = DataType::F32)
        : data_(buffer), shape_(shape), dtype_(dtype),
          size_(compute_size(shape)), capacity_(0), owned_(false) {}

    // Move constructor
    Tensor(Tensor&& other) noexcept
        : data_(other.data_), shape_(std::move(other.shape_)),
          size_(other.size_), capacity_(other.capacity_),
          dtype_(other.dtype_), owned_(other.owned_) {
        other.data_ = nullptr;
        other.size_ = 0;
        other.capacity_ = 0;
        other.owned_ = false;
    }

    // Move assignment
    Tensor& operator=(Tensor&& other) noexcept {
        if (this != &other) {
            release();
            data_ = other.data_;
            shape_ = std::move(other.shape_);
            size_ = other.size_;
            capacity_ = other.capacity_;
            dtype_ = other.dtype_;
            owned_ = other.owned_;
            other.data_ = nullptr;
            other.size_ = 0;
            other.capacity_ = 0;
            other.owned_ = false;
        }
        return *this;
    }

    // Destructor
    ~Tensor() { release(); }

    // Copy is disabled to avoid expensive copies; use Clone() explicitly
    Tensor(const Tensor&) = delete;
    Tensor& operator=(const Tensor&) = delete;

    // Explicit deep copy
    Tensor Clone() const {
        Tensor t(shape_, dtype_);
        if (data_ && t.data_) {
            std::memcpy(t.data_, data_, capacity_);
        }
        return t;
    }

    // Accessors
    void*       data()       { return data_; }
    const void* data() const { return data_; }

    template<typename T>
    T* data_as() { return static_cast<T*>(data_); }

    template<typename T>
    const T* data_as() const { return static_cast<const T*>(data_); }

    const std::vector<size_t>& shape() const { return shape_; }
    size_t ndim() const { return shape_.size(); }
    size_t size() const { return size_; }
    size_t bytes() const { return capacity_; }
    DataType dtype() const { return dtype_; }

    size_t dim(size_t i) const {
        if (i >= shape_.size()) throw std::out_of_range("dim index out of range");
        return shape_[i];
    }

    // Strides: row-major contiguous
    std::vector<size_t> strides() const {
        std::vector<size_t> s(shape_.size(), 1);
        for (int i = (int)shape_.size() - 2; i >= 0; --i) {
            s[i] = s[i+1] * shape_[i+1];
        }
        return s;
    }

    // Reshape (total elements must match)
    void reshape(const std::vector<size_t>& new_shape) {
        if (compute_size(new_shape) != size_) {
            throw std::invalid_argument("reshape: total element count mismatch");
        }
        shape_ = new_shape;
    }

    // Fill with a scalar value
    template<typename T>
    void fill(T value) {
        T* ptr = data_as<T>();
        for (size_t i = 0; i < size_; ++i) {
            ptr[i] = value;
        }
    }

private:
    void*  data_     = nullptr;
    std::vector<size_t> shape_;
    size_t size_     = 0;      // number of elements
    size_t capacity_ = 0;      // bytes allocated
    DataType dtype_  = DataType::F32;
    bool    owned_   = false;

    static size_t compute_size(const std::vector<size_t>& shape) {
        size_t s = 1;
        for (auto d : shape) s *= d;
        return s;
    }

    void release() {
        if (owned_ && data_) {
            std::free(data_);
        }
        data_ = nullptr;
        size_ = 0;
        capacity_ = 0;
        owned_ = false;
    }
};

} // namespace riscv_dl

#endif // RISCV_DL_ACCEL_TENSOR_H
