#ifndef RISCV_DL_ACCEL_API_H
#define RISCV_DL_ACCEL_API_H

#include <vector>
#include <cstdint>
#include <memory>
#include "tensor.h"

namespace riscv_dl {

// ============================================================================
// C++ Public API — lightweight frontend for inference acceleration
// ============================================================================
// All functions dispatch to the best available backend automatically.
// Users only need to include this header and link against the library.

// --- Tensor creation helpers ------------------------------------------------
Tensor create_tensor(const std::vector<int32_t>& shape);
Tensor create_tensor(const std::vector<int32_t>& shape, const std::vector<float>& data);

// --- Element-wise ops -------------------------------------------------------
Tensor add(const Tensor& a, const Tensor& b);
Tensor relu(const Tensor& x);

// --- Matrix ops -------------------------------------------------------------
Tensor matmul(const Tensor& a, const Tensor& b);

// --- Convolution ------------------------------------------------------------
// Implements 2D convolution (NHWC format). Filters shape: [KH, KW, IC, OC].
// stride and padding default to 1 and 0 respectively.
Tensor conv2d(const Tensor& input, const Tensor& filters,
              int32_t stride_h = 1, int32_t stride_w = 1,
              int32_t pad_h = 0, int32_t pad_w = 0);

// --- Backend query ----------------------------------------------------------
enum class BackendType {
    Portable,       // Naive C++ reference implementation
    ScalarOpt,      // Compiler-optimized C++ (O2/O3)
    RISCV_Asm       // RISC-V assembly / inline-asm optimized
};

BackendType active_backend();
void        force_backend(BackendType backend);

// --- Utility ----------------------------------------------------------------
void print_tensor(const Tensor& t, const char* name = nullptr);

} // namespace riscv_dl

#endif // RISCV_DL_ACCEL_API_H
